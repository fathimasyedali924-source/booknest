const books = [
{title:"Web Design Basics",author:"A. Kumar",price:299,image:"images/web-design.svg"},
{title:"JavaScript Guide",author:"R. Sharma",price:399,image:"images/javascript.svg"},
{title:"HTML & CSS",author:"P. Devi",price:249,image:"images/html-css.svg"},
{title:"Learning Python",author:"S. Raj",price:449,image:"images/python.svg"},
{title:"Database Essentials",author:"M. Anand",price:349,image:"images/database.svg"},
{title:"Modern Web Apps",author:"K. Priya",price:499,image:"images/web-apps.svg"}];
let cart=[];
function displayBooks(list=books){
 const box=document.getElementById("bookList"); box.innerHTML="";
 if(!list.length){box.innerHTML="<p>No books found.</p>";return;}
 list.forEach(book=>{box.innerHTML+=`<div class="book"><img class="cover-img" src="${book.image}" alt="${book.title}"><h3>${book.title}</h3><p>Author: ${book.author}</p><p class="price">₹${book.price}</p><button onclick="addToCart(${books.indexOf(book)})">Add to Cart</button></div>`;});
}
function addToCart(index){cart.push(books[index]);document.getElementById("cartCount").textContent=cart.length;alert(books[index].title+" added to cart!");}
function showCart(){
 const modal=document.getElementById("cartModal"),items=document.getElementById("cartItems"),msg=document.getElementById("orderMessage");
 msg.innerHTML="";
 if(!cart.length){items.innerHTML="<p>Your cart is empty.</p>";document.getElementById("placeOrderBtn").style.display="none";}
 else{items.innerHTML=cart.map((book,i)=>`<div class="cart-row"><span>${book.title}</span><span>₹${book.price} <button onclick="removeFromCart(${i})">Remove</button></span></div>`).join("");document.getElementById("placeOrderBtn").style.display="inline-block";}
 document.getElementById("cartTotal").textContent=cart.reduce((sum,b)=>sum+b.price,0);modal.style.display="flex";
}
function placeOrder(){
 if(!cart.length)return;
 const orderId="BN"+Math.floor(100000+Math.random()*900000);
 document.getElementById("orderMessage").innerHTML=`<div class="success">✅ <strong>Order Placed Successfully!</strong><br>Order ID: ${orderId}<br>Thank you for shopping with BookNest.</div>`;
 cart=[];document.getElementById("cartCount").textContent="0";document.getElementById("placeOrderBtn").style.display="none";
}
function removeFromCart(index){cart.splice(index,1);document.getElementById("cartCount").textContent=cart.length;showCart();}
function closeCart(){document.getElementById("cartModal").style.display="none";}
function searchBooks(){const text=document.getElementById("searchBox").value.toLowerCase();displayBooks(books.filter(b=>b.title.toLowerCase().includes(text)||b.author.toLowerCase().includes(text)));}
displayBooks();